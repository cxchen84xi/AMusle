#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <wiringPi.h>
#include <QString>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    wiringPiSetup();

    pinMode(7, OUTPUT);
    pinMode(9, OUTPUT);

    // 分配空间，指定父对象
    udpSocket = new QUdpSocket(this);

    // 绑定
    udpSocket->bind(8888);

    // 获取本机ip
    QString strIpAddress = QHostAddress(QHostAddress::LocalHost).toString();

    // 设置窗口的标题
    QString title = QString("Online,端口为:8888").arg(strIpAddress);
    setWindowTitle(title);

    // 当对方成功发送数据时
    // 自动触发 readyRead()
    connect(udpSocket, &QUdpSocket::readyRead, this, &MainWindow::dealMsg);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::dealMsg()
{
    char buf[512] = {0};
    QHostAddress clientAddr;
    quint16 port;

    // 读取对方发送的内容
    qint64 len = udpSocket->readDatagram(buf, sizeof(buf), &clientAddr, &port);
    if (len > 0) {
        QString msg = QString("[%1:%2] %3")
                .arg(clientAddr.toString())
                .arg(port)
                .arg(buf);

        if(msg.contains("innospace", Qt::CaseSensitive)){
            digitalWrite(7, LOW);
            digitalWrite(9,HIGH);
        }
        if(msg.contains("niubility", Qt::CaseSensitive)){
            digitalWrite(7, LOW);
            digitalWrite(9, LOW);
        }
        if(msg.contains("hackathon", Qt::CaseSensitive)){
            digitalWrite(7, HIGH);
            digitalWrite(9, LOW);
        }
        // 设置显示内容
        ui->textEdit_Msg->setText(msg);

    }
}

