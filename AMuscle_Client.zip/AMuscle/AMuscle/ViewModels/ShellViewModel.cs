﻿using AMuscle.Models;
using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
using Newtonsoft.Json.Linq;
using Newtonsoft.Json; 
using System.Net; 
using System.Net.Http;
using System.IO;
using System.Net.Sockets;
using System.Timers;

namespace AMuscle.ViewModels
{
    public class ShellViewModel:Conductor<object>
    {
         
        static Socket server;        
        EndPoint _ClientPoint = new IPEndPoint(IPAddress.Parse("172.20.10.2"), 8888); 
        public ShellViewModel()
        {
            UpdateHeroes();
             
           
            server = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            server.Bind(new IPEndPoint(IPAddress.Parse("172.20.10.4"), 6000));//绑定端口号和IP  
            

            Timer aTimer = new Timer();
            aTimer.Elapsed += new ElapsedEventHandler(TickTask);
            aTimer.Interval = 2000;//每秒执行一次
            aTimer.Enabled = true;
        }

        private void UpdateHeroes()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://1.amuscle.applinzi.com" + "/getheroes");
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();

            this.Heroes = JsonConvert.DeserializeObject<BindableCollection<HeroModel>>(retString);
        }

        private int _ID = 1;
        private string _Name = "Alpha";
        private string _Time = "2019-06-15";
        private string _Command ="InnoSpace";
        private string _IsExecuted;
        private BindableCollection<HeroModel> _Heroes = new BindableCollection<HeroModel>();
        private HeroModel _SelectedHero;

        public int ID
        {
            get {
                return _ID ;
            }
            set {
                _ID = value;
                NotifyOfPropertyChange(() => ID);
            }
        } 

        public string Name
        {
            get { return _Name; }
            set {
                _Name = value;
                NotifyOfPropertyChange(() => Name);
            }
        }

        public string Time
        {
            get { return _Time; }
            set {
                _Time = value;
                NotifyOfPropertyChange(() => Time);
            }
        }

        public string Command
        {
            get { return _Command; }
            set
            {
                _Command = value;
                NotifyOfPropertyChange(() => Command);
            }
        }

        public string IsExcuted
        {
            get { return _IsExecuted; }
            set {
                _IsExecuted = value;
                NotifyOfPropertyChange(() => IsExcuted);
            }
        }
                
        public BindableCollection<HeroModel> Heroes
        {
            get { return _Heroes; }
            set {
                _Heroes = value;
                NotifyOfPropertyChange(() => Heroes);
            }
        }
         
        public HeroModel SelectedHero
        {
            get { return _SelectedHero; }
            set {
                _SelectedHero = value;
                NotifyOfPropertyChange(() => SelectedHero);
            }
        } 
         
        private void TickTask(object sender, ElapsedEventArgs e)
        {
            
            UpdateHeroes();
            int count = Heroes.Count() - 1;
            string command = Heroes[count].Command;
            bool isExecuted = Heroes[count].IsExecuted == "True";
            if (!isExecuted)
            {
                server.SendTo(Encoding.UTF8.GetBytes( command), _ClientPoint);
            } 
        }

    }
}
