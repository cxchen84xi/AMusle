﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Caliburn.Micro;
namespace AMuscle.Models
{
    public class HeroModel
    {
        private string _ID = "1";
        private string _Name = "Alpha";
        private string _Time = "2019-06-15";
        private string _Command ="InnoSpace";

        public string ID
        {
            get {
                return _ID ;
            }
            set {
                _ID = value;
            }
        }

        public string Name
        {
            get { return _Name; }
            set {
                _Name = value;
            }
        }
        
        public string Time
        {
            get { return _Time; }
            set {
                _Time = value;
            }
        }
        
        public string Command
        {
            get { return _Command; }
            set
            {
                _Command = value;
            }
        }

        private string _IsExecuted;

        public string IsExecuted
        {
            get { return _IsExecuted; }
            set {
                _IsExecuted = value;
            }
        }
        
    }
}
