# -*- coding:utf-8 -*-
import lxml
import time
import os
import json
import web
import web.db
import sae.const

db = web.database(
    dbn = 'mysql',
    host = sae.const.MYSQL_HOST,
    port = int(sae.const.MYSQL_PORT),
    user = sae.const.MYSQL_USER,
    passwd = sae.const.MYSQL_PASS,
    db = sae.const.MYSQL_DB
)
  
def getheroes():
    return db.select('Heroes', order='ID')

class ApiGetHeroes:
    def GET(self):
        heroes = getheroes()
        rets = [] 
        for h in heroes:
            ret = {}
            ret['ID'] = h['ID']
            ret['Name'] = h['Name']
            ret['Time'] = h['Time']
            ret['Command'] = h['Command']
            ret['IsExecuted'] = h['IsExecuted']
            rets.append(ret)
        data_update = db.query("select * from Heroes order by ID desc limit 1")[0]
        id = data_update["ID"]
        db.update("Heroes", where = " ID = %s" %id, IsExecuted = 'True')
        return json.dumps(rets)