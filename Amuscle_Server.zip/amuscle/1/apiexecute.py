# -*- coding:utf-8 -*-
import lxml
import time
import os
import json
import web
import web.db
import sae.const

db = web.database(
    dbn = 'mysql',
    host = sae.const.MYSQL_HOST,
    port = int(sae.const.MYSQL_PORT),
    user = sae.const.MYSQL_USER,
    passwd = sae.const.MYSQL_PASS,
    db = sae.const.MYSQL_DB
) 
  
class ApiExcute:
    def GET(self):
        ret = db.query("select * from Heroes order by ID desc limit 1")[0]
        id = ret["ID"]
        db.update("Heroes", where = " ID = %s" %id, IsExecuted = 'True')
        return ret