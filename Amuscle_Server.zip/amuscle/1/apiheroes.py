# -*- coding:utf-8 -*-
import lxml
import time
import os
import json
import web
import web.db
import sae.const

db = web.database(
    dbn = 'mysql',
    host = sae.const.MYSQL_HOST,
    port = int(sae.const.MYSQL_PORT),
    user = sae.const.MYSQL_USER,
    passwd = sae.const.MYSQL_PASS,
    db = sae.const.MYSQL_DB
)
  
render = web.template.render('templates')

def getheroes():
    return db.select('Heroes', order='ID')

class ApiHeroes:
    def GET(self):
        return render.heroesonboard(getheroes())